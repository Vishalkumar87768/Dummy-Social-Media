import React from 'react'

const WelcomeMessage = ({onGetPostClick}) => {
  return (
    <center className='welcome-message'>
      <h1 >There are no Post</h1>
      <button onClick={onGetPostClick} type="button" className="btn btn-primary">Get post from server</button>
      </center>
  )
}

export default WelcomeMessage;