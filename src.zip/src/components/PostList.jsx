import React, { useContext, useState } from 'react';
import { Postlist as PostListData } from '../store/post-list-store';
import Post from './Post';
import WelcomeMessage from './WelcomeMessage';

export const PostList = () => {
  const { postList, addInitialPosts } = useContext(PostListData);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleGetPostClick = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch('https://dummyjson.com/posts');
      if (!response.ok) {
        throw new Error('Failed to fetch posts');
      }
      const data = await response.json();
      addInitialPosts(data.posts);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {isLoading && <p>Loading posts...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {postList.length === 0 && !isLoading && !error && (
        <WelcomeMessage onGetPostClick={handleGetPostClick} />
      )}
      {postList.map((post) => (
        <Post key={post.id} post={post} />
      ))}
    </>
  );
};

export default PostList;
