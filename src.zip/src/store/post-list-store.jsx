import { createContext, useReducer } from "react";

export const Postlist = createContext({
  postList: [],
  addPost: () => {},
  addInitialPosts: () => {},
  deletePost: () => {}
});

const postListReducer = (currPostList, action) => {
  switch (action.type) {
    case "DELETE_POST":
      return currPostList.filter((post) => post.id !== action.payload.postId);

    case "ADD_INITIAL_POSTS":
      return [...action.payload.posts]; // Always return a new array.

    case "ADD_POST":
      return [
        {
          id: Date.now(),
          userId: action.payload.userId,
          title: action.payload.title,
          body: action.payload.body,
          reactions: action.payload.reactions,
          tags: action.payload.tags
        },
        ...currPostList
      ];

    default:
      return currPostList; // Return the current state for unknown actions.
  }
};

const PostListProvider = ({ children }) => {
  const [postList, dispatchPostList] = useReducer(postListReducer, []);

  const addPost = (userId, title, body, reactions, tags) => {
    dispatchPostList({
      type: "ADD_POST",
      payload: { userId, title, body, reactions, tags }
    });
  };

  const addInitialPosts = (posts) => {
    dispatchPostList({
      type: "ADD_INITIAL_POSTS",
      payload: { posts }
    });
  };

  const deletePost = (postId) => {
    dispatchPostList({
      type: "DELETE_POST",
      payload: { postId }
    });
  };

  return (
    <Postlist.Provider value={{ postList, addPost, deletePost, addInitialPosts }}>
      {children}
    </Postlist.Provider>
  );
};

export default PostListProvider;
